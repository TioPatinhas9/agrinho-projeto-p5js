// Variáveis globais do jogo
let jardineiro; // Objeto do jardineiro
let plantas = []; // Array para armazenar as árvores plantadas
let temperatura = 10; // Temperatura inicial do planeta
let totalArvores = 0; // Contador de árvores plantadas
let pontuacao = 0; // Pontuação do jogador
let nivel = 1; // Nível atual do jogo, começa no 1

let imgMachado; // Imagem do machado
let machadoDoJogo; // Objeto do machado
let machadoCarregado = false; // Variável para verificar se a imagem do machado carregou

// Variáveis de controle do evento de corte do machado
let corteAtivo = false; // Indica se um evento de corte está em andamento
let tempoUltimoCorte = 0; // Tempo em que o último evento de corte terminou
let intervaloEntreCortesBase = 10000; // Cooldown base de 10 segundos entre os eventos de corte do machado
let intervaloEntreCortesAtual = intervaloEntreCortesBase; // Intervalo atual, que pode mudar com a dificuldade

// Regras do jogo para o machado (valores base que serão ajustados por nível)
let limiteArvoresParaCorte = 5; // O machado tenta cortar quando o total de árvores atinge múltiplos de 5
let numArvoresParaCortarBase = 5; // Quantas árvores o machado tenta cortar por evento (base)
let numArvoresParaCortarAtual = numArvoresParaCortarBase; // Quantas árvores o machado corta no nível atual
let velocidadeMachadoBase = 5; // Velocidade base do machado
let machadoVelocidadeOriginal; // Para resetar a velocidade se for modificada por uma habilidade de árvore

// Estados do jogo
let gameState = 'menu'; // Começa no estado de menu
let limiteTemperaturaPerdeu = 50; // Temperatura máxima para perder o jogo
let limiteArvoresGanhouBase = 50; // Número de árvores para ganhar o jogo (base)
let limiteArvoresGanhouAtual = limiteArvoresGanhouBase; // Número de árvores para ganhar no nível atual

// Variáveis para o sistema de partículas
let particulas = [];
let feedbacksFlutuantes = []; // Para textos de pontos +/-, etc.

// Variáveis da loja
let arvoresDisponiveis = []; // Array de objetos para as árvores da loja
let arvoreSelecionadaIndex = 0; // Índice da árvore atualmente selecionada para plantar

let upgradesDisponiveis = []; // Array de objetos para os upgrades do jardineiro
let upgradeVelocidadeComprado = false;
let upgradeCooldownPlantioComprado = false;
let cooldownPlantioBase = 200; // Cooldown mínimo entre cada plantio
let cooldownPlantioAtual = cooldownPlantioBase;
let tempoUltimoPlantio = 0;

// Variáveis de inimigos/eventos ambientais
let pragas = [];
let nuvensPoluicao = [];
let chanceAparecerPraga = 0.005; // Chance por frame
let chanceAparecerPoluicao = 0.002; // Chance por frame

// Efeito de lentidão do machado
let machadoLentoAtivo = false;
let tempoMachadoLentoFim = 0;
let duracaoMachadoLento = 5000; // 5 segundos

// Cooldown para habilidades de árvore (para não ativar sempre)
let cooldownHabilidadeArvore = 2000; // 2 segundos
let tempoUltimaHabilidadeArvore = 0;

// Variável para o aviso de machado
let avisoMachadoAtivo = false;
let tempoAvisoMachadoAtivo = 0;
let duracaoAvisoMachado = 1500; // 1.5 segundos antes do machado aparecer

/**
 * Função preload()
 * Carrega os assets do jogo antes de setup().
 */
function preload() {
  // Tenta carregar a imagem do machado. Se falhar, define machadoCarregado como false.
  imgMachado = loadImage("machado.png",
    () => { // Callback de sucesso
      machadoCarregado = true;
      console.log("Imagem do machado carregada com sucesso!");
    },
    (event) => { // Callback de erro
      machadoCarregado = false;
      console.error("Erro ao carregar a imagem do machado:", event);
      console.error("Verifique se 'machado.png' está na pasta correta e o nome está exato.");
    }
  );
}

/**
 * Função setup()
 * Configura o ambiente do jogo uma vez no início.
 */
function setup() {
  createCanvas(800, 600); // Cria a tela do jogo

  // Define as árvores disponíveis na loja
  arvoresDisponiveis = [
    { emoji: '🌲', cost: 0, pointsGain: 10, unlocked: true, ability: null }, // Árvore inicial
    { emoji: '🌴', cost: 10000, pointsGain: 50, unlocked: false, ability: 'slowMachado' }, // Palmeira
    { emoji: '🎄', cost: 20000, pointsGain: 100, unlocked: false, ability: 'bonusPontos' }, // Árvore de Natal
    { emoji: '🌵', cost: 50000, pointsGain: 200, unlocked: false, ability: 'machadoErro' } // Cacto
  ];

  // Define os upgrades disponíveis
  upgradesDisponiveis = [
    { name: 'Botas de Velocidade', emoji: '👟', cost: 5000, type: 'velocidade', effect: 1.5, unlocked: false }, // Aumenta velocidade do jardineiro
    { name: 'Fertilizante Rápido', emoji: '💧', cost: 7500, type: 'cooldownPlantio', effect: 0.5, unlocked: false } // Diminui cooldown de plantio
  ];

  // Inicia o jogo no estado de menu
  iniciarNovoJogo();
}

/**
 * Função draw()
 * Loop principal do jogo, executado continuamente.
 */
function draw() {
  switch (gameState) {
    case 'menu':
      mostrarMenuInicial();
      break;
    case 'jogando':
      logicaJogo();
      break;
    case 'loja':
      mostrarLoja();
      break;
    case 'ganhou':
      mostrarTelaFinal("Você salvou o planeta! 🎉", color(0, 150, 0));
      break;
    case 'perdeu':
      mostrarTelaFinal("O planeta foi destruído! 💀", color(200, 0, 0));
      break;
  }

  // Atualiza e exibe feedbacks flutuantes em todos os estados que não são o menu inicial ou telas finais
  if (gameState !== 'menu' && gameState !== 'ganhou' && gameState !== 'perdeu') {
      gerenciarFeedbacks();
  }
}

/**
 * Função logicaJogo()
 * Contém a lógica principal do jogo quando o estado é 'jogando'.
 */
function logicaJogo() {
  // Calcula a cor de fundo baseada na quantidade de árvores (efeito de mudança ambiental)
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, limiteArvoresGanhouAtual, 0, 1));
  background(corFundo); // Define a cor de fundo

  mostrarInformacao(); // Exibe informações na tela

  // Barra de Temperatura
  desenharBarraTemperatura();

  // Botão para acessar a loja
  fill(100, 150, 255);
  rect(width - 120, 10, 110, 40, 5);
  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Loja", width - 65, 30);

  // Lógica do machado: exibe e atualiza sua posição se estiver visível
  machadoDoJogo.exibir();
  if (machadoDoJogo.visivel) {
    machadoDoJogo.atualizar();
  }

  // Desacelerar machado por habilidade de árvore
  if (machadoLentoAtivo && millis() > tempoMachadoLentoFim) {
      machadoDoJogo.velocidade = machadoVelocidadeOriginal; // Restaura velocidade
      machadoLentoAtivo = false;
      console.log("Velocidade do machado restaurada.");
  }


  temperatura += 0.05; // Aumenta a temperatura gradualmente ao longo do tempo
  jardineiro.mostrar(); // Exibe o jardineiro
  jardineiro.atualizar(); // Atualiza a posição do jardineiro

  // Gerencia inimigos e eventos ambientais
  gerenciarInimigos();
  gerenciarNuvensPoluicao();

  // Itera sobre todas as plantas para exibi-las
  // Percorre o array de trás para frente para remover elementos sem problemas
  for (let i = plantas.length - 1; i >= 0; i--) {
    let arvore = plantas[i];
    arvore.mostrar();
  }

  // Lógica para o machado cortar árvores:
  // Ativa o machado se:
  // 1. O número total de árvores é maior ou igual ao limite para corte
  // 2. O número total de árvores é um múltiplo do limite para corte (ex: 5, 10, 15...)
  // 3. Não há um evento de corte ativo no momento
  // 4. Já passou o tempo de cooldown desde o último corte
  // 5. Não há aviso de machado ativo ou o aviso já terminou
  if (totalArvores >= limiteArvoresParaCorte &&
      totalArvores % limiteArvoresParaCorte === 0 &&
      !corteAtivo &&
      millis() - tempoUltimoCorte > intervaloEntreCortesAtual) {

      // Ativar aviso do machado
      if (!avisoMachadoAtivo) {
          avisoMachadoAtivo = true;
          tempoAvisoMachadoAtivo = millis();
          console.log("Aviso de machado ativo!");
      }

      // Se o aviso terminou, ativar o machado
      if (avisoMachadoAtivo && millis() - tempoAvisoMachadoAtivo > duracaoAvisoMachado) {
          avisoMachadoAtivo = false;
          tempoUltimoCorte = millis(); // Reseta o cooldown para evitar ativação instantânea no próximo ciclo
          let arvoresDisponiveisParaCorte = plantas.filter(arvore => !arvore.cortada && !arvore.sendoAlvo);

          if (arvoresDisponiveisParaCorte.length >= numArvoresParaCortarAtual) {
              corteAtivo = true; // Inicia o evento de corte
              let alvosParaCorte = [];
              for (let i = 0; i < numArvoresParaCortarAtual; i++) {
                  let randomIndex = floor(random(arvoresDisponiveisParaCorte.length));
                  alvosParaCorte.push(arvoresDisponiveisParaCorte[randomIndex]);
                  arvoresDisponiveisParaCorte.splice(randomIndex, 1);
              }
              machadoDoJogo.ativar(alvosParaCorte);
          } else if (arvoresDisponiveisParaCorte.length > 0) { // Corta o que tem se não for suficiente
              corteAtivo = true;
              machadoDoJogo.ativar(arvoresDisponiveisParaCorte);
          }
      }
  }

  // Exibir aviso de machado
  if (avisoMachadoAtivo) {
      fill(255, 0, 0, 150 + sin(frameCount * 0.1) * 100); // Vermelho pulsante
      textSize(30);
      textAlign(CENTER, TOP);
      text("MACHADO ATIVO!", width / 2, height * 0.1);
  }

  // Atualiza e exibe as partículas
  gerenciarParticulas();

  // Condições de vitória e derrota
  if (temperatura >= limiteTemperaturaPerdeu) {
    gameState = 'perdeu'; // Muda o estado para 'perdeu' se a temperatura atingir o limite
  } else if (totalArvores >= limiteArvoresGanhouAtual) {
    gameState = 'ganhou'; // Muda o estado para 'ganhou' se o número de árvores atingir o limite
  }
}

/**
 * Função desenharBarraTemperatura()
 * Desenha a barra de temperatura na parte superior da tela.
 */
function desenharBarraTemperatura() {
    let barWidth = width * 0.8;
    let barHeight = 20;
    let barX = (width - barWidth) / 2;
    let barY = 10;

    // Fundo da barra
    fill(200);
    rect(barX, barY, barWidth, barHeight, 5);

    // Cor da barra de preenchimento (verde -> vermelho)
    let tempColor = lerpColor(color(0, 200, 0), color(200, 0, 0), map(temperatura, 0, limiteTemperaturaPerdeu, 0, 1));
    let fillWidth = map(temperatura, 0, limiteTemperaturaPerdeu, 0, barWidth);
    fill(tempColor);
    rect(barX, barY, fillWidth, barHeight, 5);

    // Texto da temperatura
    fill(255); // Branco
    textSize(14);
    textAlign(CENTER, CENTER);
    text("Temperatura: " + temperatura.toFixed(1) + "°C", width / 2, barY + barHeight / 2);
}


/**
 * Função mostrarMenuInicial()
 * Exibe a tela do menu inicial.
 */
function mostrarMenuInicial() {
  background(150, 200, 255); // Fundo azul claro
  fill(255);
  textSize(50);
  textAlign(CENTER, CENTER);
  text("Jardineiro do Planeta", width / 2, height / 2 - 80);

  // Botão Iniciar Jogo
  fill(0, 180, 0); // Verde
  rect(width / 2 - 100, height / 2, 200, 60, 10);
  fill(255);
  textSize(30);
  text("Iniciar Jogo", width / 2, height / 2 + 30);
}

/**
 * Função mostrarLoja()
 * Exibe a tela da loja de árvores e upgrades.
 */
function mostrarLoja() {
  background(180, 180, 180); // Fundo cinza para a loja
  fill(0);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("Loja do Jardineiro", width / 2, 50);

  // Título da pontuação
  textSize(25);
  textAlign(LEFT, TOP);
  text("Seus Pontos: " + pontuacao, 20, 20);

  // --- Seção de Árvores ---
  textSize(30);
  textAlign(LEFT, TOP);
  text("Árvores:", 50, 100);

  let startX = 50;
  let startY = 150;
  let itemWidth = 120;
  let itemHeight = 150;
  let padding = 30;

  for (let i = 0; i < arvoresDisponiveis.length; i++) {
    let arvore = arvoresDisponiveis[i];
    let x = startX + i * (itemWidth + padding);
    let y = startY;

    if (i === arvoreSelecionadaIndex) {
      stroke(255, 200, 0);
      strokeWeight(4);
    } else {
      noStroke();
    }
    fill(200, 200, 200);
    rect(x, y, itemWidth, itemHeight, 10);

    textSize(50);
    textAlign(CENTER, CENTER);
    text(arvore.emoji, x + itemWidth / 2, y + itemHeight / 2 - 20);

    textSize(18);
    fill(0);
    text("Pontos: " + arvore.pointsGain, x + itemWidth / 2, y + itemHeight / 2 + 30);

    if (arvore.unlocked) {
      fill(0, 150, 0);
      textSize(16);
      text("Desbloqueado", x + itemWidth / 2, y + itemHeight - 25);
      if (i === arvoreSelecionadaIndex) {
        fill(0, 0, 200);
        text("Selecionado", x + itemWidth / 2, y + itemHeight - 5);
      } else {
        fill(0, 100, 0);
        text("Selecionar", x + itemWidth / 2, y + itemHeight - 5);
      }
    } else {
      fill(200, 0, 0);
      textSize(16);
      text("Custo: " + arvore.cost, x + itemWidth / 2, y + itemHeight - 25);
      fill(150, 150, 150);
      text("Comprar", x + itemWidth / 2, y + itemHeight - 5);
    }
  }

  // --- Seção de Upgrades ---
  textSize(30);
  textAlign(LEFT, TOP);
  text("Upgrades:", 50, startY + itemHeight + padding + 20);

  let upgradeStartX = 50;
  let upgradeStartY = startY + itemHeight + padding + 70;
  let upgradeItemWidth = 120;
  let upgradeItemHeight = 100;
  let upgradePadding = 30;

  for (let i = 0; i < upgradesDisponiveis.length; i++) {
      let upgrade = upgradesDisponiveis[i];
      let x = upgradeStartX + i * (upgradeItemWidth + upgradePadding);
      let y = upgradeStartY;

      noStroke();
      fill(200, 200, 200);
      rect(x, y, upgradeItemWidth, upgradeItemHeight, 10);

      textSize(40);
      textAlign(CENTER, CENTER);
      text(upgrade.emoji, x + upgradeItemWidth / 2, y + upgradeItemHeight / 2 - 10);

      textSize(14);
      fill(0);
      text(upgrade.name, x + upgradeItemWidth / 2, y + upgradeItemHeight / 2 + 20);

      if (upgrade.unlocked) {
          fill(0, 150, 0);
          textSize(14);
          text("Comprado", x + upgradeItemWidth / 2, y + upgradeItemHeight - 15);
      } else {
          fill(200, 0, 0);
          textSize(14);
          text("Custo: " + upgrade.cost, x + upgradeItemWidth / 2, y + upgradeItemHeight - 15);
          fill(150, 150, 150);
          text("Comprar", x + upgradeItemWidth / 2, y + upgradeItemHeight - 2);
      }
  }

  // Botão Voltar ao Jogo
  fill(0, 100, 0); // Verde escuro
  rect(width / 2 - 80, height - 70, 160, 50, 10);
  fill(255);
  textSize(25);
  text("Voltar ao Jogo", width / 2, height - 45);
}


/**
 * Função mostrarInformacao()
 * Exibe as informações do jogo na tela.
 */
function mostrarInformacao() {
  textSize(20);
  fill(0); // Cor preta para o texto
  textAlign(LEFT, TOP);
  text("Nível: " + nivel, 10, 30); // Exibe o nível atual
  text("Árvores: " + totalArvores + "/" + limiteArvoresGanhouAtual, 10, 50); // Exibe árvores plantadas vs. objetivo
  text("Pontuação: " + pontuacao, 10, 70); // Exibe a pontuação
  textSize(25);
  text("Plantando: " + arvoresDisponiveis[arvoreSelecionadaIndex].emoji, 10, 100); // Mostra a árvore selecionada

  // Mostra upgrades ativos
  textSize(16);
  let activeUpgrades = "";
  if (upgradeVelocidadeComprado) activeUpgrades += "👟 ";
  if (upgradeCooldownPlantioComprado) activeUpgrades += "💧 ";
  if (activeUpgrades !== "") {
    text("Ativos: " + activeUpgrades, 10, 125);
  }

  textSize(16); // Texto menor para as instruções
  textAlign(LEFT, BOTTOM);
  text("Mover: Setas | Plantar: P/Espaço", 10, height - 5);
}

/**
 * Função mostrarTelaFinal(mensagem, cor)
 * Exibe a tela de vitória ou derrota.
 * @param {string} mensagem - A mensagem a ser exibida.
 * @param {p5.Color} cor - A cor de fundo da tela.
 */
function mostrarTelaFinal(mensagem, cor) {
  background(cor); // Define a cor de fundo da tela final
  fill(255); // Cor branca para o texto
  textSize(40);
  textAlign(CENTER, CENTER); // Centraliza o texto
  text(mensagem, width / 2, height / 2 - 30); // Exibe a mensagem principal
  textSize(20);
  // Se ganhou, oferece a opção de ir para o próximo nível
  if (gameState === 'ganhou') {
    text("Pressione 'N' para o próximo nível ou 'R' para reiniciar", width / 2, height / 2 + 30);
  } else {
    text("Pressione 'R' para reiniciar", width / 2, height / 2 + 30); // Exibe a instrução para reiniciar
  }
}

/**
 * Classe Jardineiro
 * Representa o personagem do jogador.
 */
class Jardineiro {
  constructor(x, y) {
    this.x = x; // Posição X
    this.y = y; // Posição Y
    this.emoji = '👨‍🌾'; // Emoji do jardineiro
    this.velocidadeBase = 3;
    this.velocidade = this.velocidadeBase; // Velocidade de movimento
  }

  /**
   * Atualiza a posição do jardineiro com base nas teclas pressionadas.
   */
  atualizar() {
    this.velocidade = this.velocidadeBase * (upgradeVelocidadeComprado ? upgradesDisponiveis[0].effect : 1);

    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o jardineiro dentro dos limites da tela
    this.x = constrain(this.x, 0, width - 32); // Ajuste 32 para o tamanho aproximado do emoji
    this.y = constrain(this.y, 0, height - 32);

    // Colisão com pragas
    for (let i = pragas.length - 1; i >= 0; i--) {
        let praga = pragas[i];
        if (dist(this.x + 16, this.y + 16, praga.x + 8, praga.y + 8) < 25) {
            pragas.splice(i, 1);
            adicionarFeedback(praga.x, praga.y, "+20", color(0, 150, 0)); // Pontos por remover praga
            pontuacao += 20;
        }
    }

    // Colisão com nuvens de poluição
    for (let i = nuvensPoluicao.length - 1; i >= 0; i--) {
        let nuvem = nuvensPoluicao[i];
        if (dist(this.x + 16, this.y + 16, nuvem.x + 16, nuvem.y + 16) < 30) {
            nuvensPoluicao.splice(i, 1);
            adicionarFeedback(nuvem.x, nuvem.y, "+30", color(0, 180, 180)); // Pontos por limpar poluição
            temperatura -= 10; // Diminui temperatura ao limpar poluição
            pontuacao += 30;
            if (temperatura < 0) temperatura = 0;
        }
    }
  }

  /**
   * Exibe o jardineiro na tela.
   */
  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

/**
 * Função keyPressed()
 * Lida com eventos de pressionamento de tecla.
 */
function keyPressed() {
  if (gameState === 'jogando') {
    // Se a tecla for 'espaço' ou 'p', planta uma árvore
    if ((key === ' ' || key === 'p') && millis() - tempoUltimoPlantio > cooldownPlantioAtual) {
      let arvore = new Arvore(jardineiro.x, jardineiro.y, arvoresDisponiveis[arvoreSelecionadaIndex].emoji);
      plantas.push(arvore); // Adiciona a nova árvore ao array
      totalArvores++; // Incrementa o contador de árvores
      temperatura -= 3; // Diminui a temperatura ao plantar uma árvore
      pontuacao += arvoresDisponiveis[arvoreSelecionadaIndex].pointsGain; // Ganha pontos da árvore selecionada
      adicionarFeedback(jardineiro.x + 16, jardineiro.y, "+" + arvoresDisponiveis[arvoreSelecionadaIndex].pointsGain, color(0, 150, 0));

      if (temperatura < 0) temperatura = 0; // Garante que a temperatura não seja negativa
      // Adiciona partículas verdes ao plantar
      for (let i = 0; i < 10; i++) {
        particulas.push(new Particula(jardineiro.x + 16, jardineiro.y + 16, color(0, 200, 0, 150)));
      }
      tempoUltimoPlantio = millis(); // Atualiza o tempo do último plantio

      // Ativar habilidade da árvore (se houver e não estiver em cooldown)
      let arvorePlantada = arvoresDisponiveis[arvoreSelecionadaIndex];
      if (arvorePlantada.ability && millis() - tempoUltimaHabilidadeArvore > cooldownHabilidadeArvore) {
          ativarHabilidadeArvore(arvorePlantada.ability);
          tempoUltimaHabilidadeArvore = millis();
      }
    }
  } else if (key === 'r' || key === 'R') {
    // Se o jogo terminou e a tecla 'r' for pressionada, reinicia o jogo
    iniciarNovoJogo(); // Reinicia completamente o jogo
  } else if (gameState === 'ganhou' && (key === 'n' || key === 'N')) {
    // Se ganhou e a tecla 'n' for pressionada, avança para o próximo nível
    proximoNivel();
  }
}

/**
 * Função mousePressed()
 * Lida com cliques do mouse para os botões do menu e loja.
 */
function mousePressed() {
  if (gameState === 'menu') {
    // Botão Iniciar Jogo
    if (mouseX > width / 2 - 100 && mouseX < width / 2 + 100 &&
        mouseY > height / 2 && mouseY < height / 2 + 60) {
      gameState = 'jogando';
    }
  } else if (gameState === 'jogando') {
    // Botão Loja
    if (mouseX > width - 120 && mouseX < width - 10 &&
        mouseY > 10 && mouseY < 50) {
      gameState = 'loja';
    }
  } else if (gameState === 'loja') {
    // Botão Voltar ao Jogo
    if (mouseX > width / 2 - 80 && mouseX < width / 2 + 80 &&
        mouseY > height - 70 && mouseY < height - 20) {
      gameState = 'jogando';
    }

    // --- Lógica para comprar e selecionar árvores na loja ---
    let arvoreStartX = 50;
    let arvoreStartY = 150;
    let itemWidth = 120;
    let itemHeight = 150;
    let padding = 30;

    for (let i = 0; i < arvoresDisponiveis.length; i++) {
      let arvore = arvoresDisponiveis[i];
      let x = arvoreStartX + i * (itemWidth + padding);
      let y = arvoreStartY;

      if (mouseX > x && mouseX < x + itemWidth &&
          mouseY > y && mouseY < y + itemHeight) {
        if (arvore.unlocked) {
          // Seleciona a árvore se já estiver desbloqueada
          arvoreSelecionadaIndex = i;
        } else {
          // Tenta comprar a árvore se tiver pontos suficientes
          if (pontuacao >= arvore.cost) {
            pontuacao -= arvore.cost;
            arvore.unlocked = true;
            arvoreSelecionadaIndex = i; // Seleciona a árvore recém-comprada
            console.log("Árvore " + arvore.emoji + " comprada!");
          } else {
            adicionarFeedback(mouseX, mouseY, "Pontos Insuficientes!", color(255, 0, 0));
            console.log("Pontos insuficientes para comprar " + arvore.emoji);
          }
        }
      }
    }

    // --- Lógica para comprar upgrades na loja ---
    let upgradeStartX = 50;
    let upgradeStartY = arvoreStartY + itemHeight + padding + 70;
    let upgradeItemWidth = 120;
    let upgradeItemHeight = 100;
    let upgradePadding = 30;

    for (let i = 0; i < upgradesDisponiveis.length; i++) {
        let upgrade = upgradesDisponiveis[i];
        let x = upgradeStartX + i * (upgradeItemWidth + upgradePadding);
        let y = upgradeStartY;

        if (mouseX > x && mouseX < x + upgradeItemWidth &&
            mouseY > y && mouseY < y + upgradeItemHeight) {
            if (!upgrade.unlocked) {
                if (pontuacao >= upgrade.cost) {
                    pontuacao -= upgrade.cost;
                    upgrade.unlocked = true;
                    if (upgrade.type === 'velocidade') {
                        upgradeVelocidadeComprado = true;
                    } else if (upgrade.type === 'cooldownPlantio') {
                        upgradeCooldownPlantioComprado = true;
                        cooldownPlantioAtual = cooldownPlantioBase * upgrade.effect; // Aplica o efeito de redução
                    }
                    console.log("Upgrade " + upgrade.name + " comprado!");
                    adicionarFeedback(mouseX, mouseY, "Upgrade Comprado!", color(0, 0, 200));
                } else {
                    adicionarFeedback(mouseX, mouseY, "Pontos Insuficientes!", color(255, 0, 0));
                    console.log("Pontos insuficientes para comprar " + upgrade.name);
                }
            }
        }
    }
  }
}

/**
 * Função ativarHabilidadeArvore(tipo)
 * Ativa uma habilidade especial de árvore.
 * @param {string} tipo - O tipo de habilidade a ser ativada.
 */
function ativarHabilidadeArvore(tipo) {
    let chance = random(); // Chance de ativar a habilidade
    console.log("Tentando ativar habilidade: " + tipo + " com chance " + chance.toFixed(2));

    switch (tipo) {
        case 'slowMachado': // Palmeira (🌴) - Diminui velocidade do machado
            if (chance < 0.3) { // 30% de chance
                machadoVelocidadeOriginal = machadoDoJogo.velocidade; // Salva a velocidade original
                machadoDoJogo.velocidade *= 0.5; // Diminui a velocidade do machado em 50%
                machadoLentoAtivo = true;
                tempoMachadoLentoFim = millis() + duracaoMachadoLento;
                adicionarFeedback(machadoDoJogo.x, machadoDoJogo.y, "MACHADO LENTO!", color(0, 0, 255));
                console.log("Habilidade: Machado lento ativado!");
            }
            break;
        case 'bonusPontos': // Árvore de Natal (🎄) - Bônus de pontos
            if (chance < 0.2) { // 20% de chance
                let bonus = 100;
                pontuacao += bonus;
                adicionarFeedback(jardineiro.x, jardineiro.y, "+" + bonus + " BÔNUS!", color(255, 200, 0));
                console.log("Habilidade: Bônus de pontos ativado!");
            }
            break;
        case 'machadoErro': // Cacto (🌵) - Faz o machado errar o alvo
            if (chance < 0.25) { // 25% de chance
                if (machadoDoJogo.alvos.length > 0) {
                    let alvoAtual = machadoDoJogo.alvos[machadoDoJogo.indiceAlvoAtual];
                    if (alvoAtual) {
                        alvoAtual.sendoAlvo = false; // Libera o alvo atual
                        machadoDoJogo.indiceAlvoAtual++; // Pula para o próximo alvo
                        adicionarFeedback(alvoAtual.x, alvoAtual.y, "ESCAPOU!", color(255, 100, 0));
                        console.log("Habilidade: Machado errou o alvo!");
                    }
                }
            }
            break;
    }
}


/**
 * Classe Arvore
 * Representa uma árvore no jogo.
 */
class Arvore {
  constructor(x, y, emoji) {
    this.x = x; // Posição X
    this.y = y; // Posição Y
    this.emoji = emoji; // Emoji da árvore (agora pode ser diferente)
    this.cortada = false; // Estado: true se a árvore foi cortada, false caso contrário
    this.sendoAlvo = false; // Estado: true se a árvore está sendo perseguida pelo machado
  }

  /**
   * Exibe a árvore na tela.
   */
  mostrar() {
    if (!this.cortada) {
      textSize(32);
      text(this.emoji, this.x, this.y);
    } else {
      // Se a árvore foi cortada, exibe um emoji de toco ou árvore morta
      textSize(32);
      text('🌳', this.x, this.y);
    }
  }
}

/**
 * Classe Machado
 * Representa o machado que corta as árvores.
 */
class Machado {
  constructor() {
    this.x = 0; // Posição X
    this.y = 0; // Posição Y
    this.largura = 50; // Largura da imagem do machado
    this.altura = 50; // Altura da imagem do machado
    this.visivel = false; // Estado: true se o machado está visível
    this.velocidade = velocidadeMachadoBase; // Velocidade de movimento do machado (agora variável)
    this.alvos = []; // Array de árvores que o machado vai cortar nesta rodada
    this.indiceAlvoAtual = 0; // Índice da árvore atual que o machado está perseguindo
  }

  /**
   * Ativa o machado e define seus alvos.
   * @param {Array<Arvore>} alvosArvores - Um array de objetos Arvore que o machado deve cortar.
   */
  ativar(alvosArvores) {
    if (alvosArvores.length === 0) return; // Não ativa se não houver alvos
    this.alvos = alvosArvores; // Define os alvos
    this.indiceAlvoAtual = 0; // Começa pelo primeiro alvo
    this.visivel = true; // Torna o machado visível
    this.x = random(width - this.largura); // Posição X de aparição aleatória
    this.y = random(height * 0.1, height * 0.4); // Posição Y de aparição aleatória (parte superior da tela)

    // Marca as árvores como "sendo alvo" para evitar que sejam selecionadas novamente
    this.alvos.forEach(arvore => arvore.sendoAlvo = true);
  }

  /**
   * Atualiza a posição do machado, movendo-o em direção ao seu alvo.
   */
  atualizar() {
    if (!this.visivel || this.alvos.length === 0) return; // Não faz nada se não estiver visível ou sem alvos

    let alvo = this.alvos[this.indiceAlvoAtual]; // Pega o alvo atual

    // Se o alvo não existe ou já foi cortado, avança para o próximo
    if (!alvo || alvo.cortada) {
      this.indiceAlvoAtual++;
      if (this.indiceAlvoAtual >= this.alvos.length) {
        this.reset(); // Se todos os alvos foram processados, reseta o machado
        return;
      }
      alvo = this.alvos[this.indiceAlvoAtual]; // Pega o novo alvo
    }

    // Calcula a posição central do alvo (emoji da árvore)
    let targetX = alvo.x + 16;
    let targetY = alvo.y - 8;

    // Calcula a direção e distância para o alvo
    let dx = targetX - (this.x + this.largura / 2);
    let dy = targetY - (this.y + this.altura / 2);
    let distancia = dist(this.x + this.largura / 2, this.y + this.altura / 2, targetX, targetY);

    // Move o machado em direção ao alvo
    if (distancia > this.velocidade) {
      this.x += (dx / distancia) * this.velocidade;
      this.y += (dy / distancia) * this.velocidade;
    } else {
      // Se o machado chegou perto o suficiente do alvo
      this.x = targetX - this.largura / 2;
      this.y = targetY - this.altura / 2;

      // Se a árvore ainda não foi cortada, corta-a
      if (!alvo.cortada) {
        alvo.cortada = true; // Marca a árvore como cortada
        totalArvores--; // Diminui o contador de árvores
        temperatura += 5; // Aumenta a temperatura como penalidade
        pontuacao -= 5; // Perde 5 pontos ao ter uma árvore cortada
        adicionarFeedback(alvo.x + 16, alvo.y, "-5", color(255, 0, 0));
        // Adiciona partículas vermelhas ao cortar
        for (let i = 0; i < 15; i++) {
          particulas.push(new Particula(alvo.x + 16, alvo.y + 16, color(200, 0, 0, 150)));
        }
        console.log("Árvore cortada!");
      }

      // Passa para o próximo alvo
      this.indiceAlvoAtual++;
      if (this.indiceAlvoAtual >= this.alvos.length) {
        this.reset(); // Se todos os alvos foram cortados, reseta o machado
      }
    }
  }

  /**
   * Exibe a imagem do machado na tela, se estiver visível.
   */
  exibir() {
    if (this.visivel) {
      // Se a imagem do machado carregou, exibe-a
      if (machadoCarregado) {
        image(imgMachado, this.x, this.y, this.largura, this.altura);
      } else {
        // Caso contrário, desenha um retângulo vermelho como substituto
        fill(255, 0, 0); // Cor vermelha
        rect(this.x, this.y, this.largura, this.altura);
      }
    }
  }

  /**
   * Reseta o estado do machado, tornando-o invisível e limpando os alvos.
   */
  reset() {
    this.visivel = false; // Torna o machado invisível
    this.alvos = []; // Limpa a lista de alvos
    this.indiceAlvoAtual = 0; // Reseta o índice do alvo
    corteAtivo = false; // Sinaliza que o evento de corte terminou
    tempoUltimoCorte = millis(); // Registra o tempo do último corte
    // Reseta o estado 'sendoAlvo' de todas as árvores (importante para futuras seleções)
    plantas.forEach(arvore => arvore.sendoAlvo = false);
  }
}

/**
 * Classe Particula
 * Representa uma partícula para efeitos visuais.
 */
class Particula {
  constructor(x, y, cor) {
    this.x = x;
    this.y = y;
    this.vx = random(-1, 1); // Velocidade horizontal aleatória
    this.vy = random(-2, -0.5); // Velocidade vertical para cima
    this.alpha = 255; // Transparência inicial
    this.cor = cor; // Cor da partícula
    this.tamanho = random(5, 10); // Tamanho da partícula
  }

  /**
   * Atualiza a posição e transparência da partícula.
   */
  atualizar() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 5; // Faz a partícula desaparecer gradualmente
  }

  /**
   * Exibe a partícula na tela.
   */
  mostrar() {
    noStroke();
    fill(this.cor.levels[0], this.cor.levels[1], this.cor.levels[2], this.alpha);
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  /**
   * Verifica se a partícula já desapareceu.
   * @returns {boolean} True se a partícula deve ser removida, false caso contrário.
   */
  isFinished() {
    return this.alpha < 0;
  }
}

/**
 * Função gerenciarParticulas()
 * Atualiza e exibe todas as partículas ativas.
 */
function gerenciarParticulas() {
  for (let i = particulas.length - 1; i >= 0; i--) {
    particulas[i].atualizar();
    particulas[i].mostrar();
    if (particulas[i].isFinished()) {
      particulas.splice(i, 1); // Remove partículas que já desapareceram
    }
  }
}

/**
 * Classe FeedbackFlutuante
 * Exibe textos temporários flutuantes (ex: +pontos, -pontos).
 */
class FeedbackFlutuante {
    constructor(x, y, texto, cor) {
        this.x = x;
        this.y = y;
        this.texto = texto;
        this.cor = cor;
        this.alpha = 255;
        this.vy = -0.8; // Move para cima
        this.tamanhoTexto = 18;
    }

    atualizar() {
        this.y += this.vy;
        this.alpha -= 4; // Desaparece gradualmente
    }

    mostrar() {
        fill(this.cor.levels[0], this.cor.levels[1], this.cor.levels[2], this.alpha);
        textSize(this.tamanhoTexto);
        textAlign(CENTER, CENTER);
        text(this.texto, this.x, this.y);
    }

    isFinished() {
        return this.alpha < 0;
    }
}

/**
 * Função adicionarFeedback(x, y, texto, cor)
 * Adiciona um novo feedback flutuante na tela.
 */
function adicionarFeedback(x, y, texto, cor) {
    feedbacksFlutuantes.push(new FeedbackFlutuante(x, y, texto, cor));
}

/**
 * Função gerenciarFeedbacks()
 * Atualiza e exibe todos os feedbacks flutuantes.
 */
function gerenciarFeedbacks() {
    for (let i = feedbacksFlutuantes.length - 1; i >= 0; i--) {
        feedbacksFlutuantes[i].atualizar();
        feedbacksFlutuantes[i].mostrar();
        if (feedbacksFlutuantes[i].isFinished()) {
            feedbacksFlutuantes.splice(i, 1);
        }
    }
}

/**
 * Classe Praga
 * Representa uma praga que ataca as árvores.
 */
class Praga {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.emoji = '�';
        this.velocidade = random(0.5, 1.5);
        this.alvoArvores = []; // Árvores que esta praga está atacando
        this.danoPorSegundo = 0.05; // Dano que causa à temperatura por segundo
    }

    atualizar() {
        // Movimento aleatório ou em direção a uma árvore
        if (random() < 0.02) { // Muda de direção ocasionalmente
            this.vx = random(-1, 1);
            this.vy = random(-1, 1);
        }
        this.x += this.vx * this.velocidade;
        this.y += this.vy * this.velocidade;

        // Limita a praga na tela
        this.x = constrain(this.x, 0, width - 20);
        this.y = constrain(this.y, 0, height - 20);

        // Se estiver perto de uma árvore, aumenta a temperatura
        for (let arvore of plantas) {
            if (!arvore.cortada && dist(this.x, this.y, arvore.x, arvore.y) < 40) {
                temperatura += this.danoPorSegundo; // Causa dano contínuo
            }
        }
    }

    mostrar() {
        textSize(20);
        text(this.emoji, this.x, this.y);
    }
}

/**
 * Função gerenciarInimigos()
 * Adiciona e atualiza as pragas.
 */
function gerenciarInimigos() {
    if (random() < chanceAparecerPraga * (nivel * 0.1)) { // Aumenta a chance com o nível
        let x = random(width);
        let y = random(height);
        pragas.push(new Praga(x, y));
    }

    for (let i = pragas.length - 1; i >= 0; i--) {
        pragas[i].atualizar();
        pragas[i].mostrar();
    }
}

/**
 * Classe NuvemPoluicao
 * Representa uma nuvem de poluição que aumenta a temperatura.
 */
class NuvemPoluicao {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.emoji = '☁️';
        this.tamanho = random(30, 50);
        this.danoPorSegundo = 0.1; // Aumento da temperatura por segundo
    }

    atualizar() {
        // Nuvens se movem lentamente
        this.x += sin(frameCount * 0.01) * 0.5;
        this.y += cos(frameCount * 0.01) * 0.5;

        // Aumenta a temperatura enquanto está ativa
        temperatura += this.danoPorSegundo;
    }

    mostrar() {
        textSize(this.tamanho);
        text(this.emoji, this.x, this.y);
    }
}

/**
 * Função gerenciarNuvensPoluicao()
 * Adiciona e atualiza as nuvens de poluição.
 */
function gerenciarNuvensPoluicao() {
    if (random() < chanceAparecerPoluicao * (nivel * 0.05)) { // Aumenta a chance com o nível
        let x = random(width);
        let y = random(height / 2); // Mais na parte superior da tela
        nuvensPoluicao.push(new NuvemPoluicao(x, y));
    }

    for (let i = nuvensPoluicao.length - 1; i >= 0; i--) {
        nuvensPoluicao[i].atualizar();
        nuvensPoluicao[i].mostrar();
    }
}

/**
 * Função iniciarNovoJogo()
 * Reinicia o jogo completamente para o nível 1.
 */
function iniciarNovoJogo() {
  nivel = 1; // Reseta o nível para 1
  pontuacao = 0; // Reseta a pontuação
  // Reseta o estado de desbloqueio das árvores da loja para o início do jogo
  arvoresDisponiveis.forEach((arvore, index) => {
    arvore.unlocked = (index === 0); // Apenas a primeira árvore está desbloqueada
  });
  arvoreSelecionadaIndex = 0; // Seleciona a árvore padrão

  // Reseta os upgrades
  upgradesDisponiveis.forEach(upgrade => upgrade.unlocked = false);
  upgradeVelocidadeComprado = false;
  upgradeCooldownPlantioComprado = false;
  cooldownPlantioAtual = cooldownPlantioBase;

  proximoNivel(); // Configura o jogo para o nível 1
}

/**
 * Função proximoNivel()
 * Configura o jogo para o próximo nível, aumentando a dificuldade.
 */
function proximoNivel() {
  jardineiro = new Jardineiro(width / 2, height - 50); // Reinicia a posição do jardineiro
  machadoDoJogo = new Machado(); // Reinicia o objeto do machado
  plantas = []; // Limpa todas as árvores
  pragas = []; // Limpa pragas
  nuvensPoluicao = []; // Limpa nuvens
  temperatura = 10; // Reinicia a temperatura
  totalArvores = 0; // Reinicia o contador de árvores plantadas
  pontuacao += 100 * nivel; // Ganha pontos bônus por completar o nível (mantido)
  corteAtivo = false;
  tempoUltimoCorte = 0;
  particulas = []; // Limpa as partículas
  feedbacksFlutuantes = []; // Limpa feedbacks
  avisoMachadoAtivo = false; // Reseta aviso do machado
  machadoLentoAtivo = false; // Reseta o efeito de lentidão
  tempoMachadoLentoFim = 0; // Reseta o tempo de fim de lentidão
  tempoUltimaHabilidadeArvore = 0; // Reseta o cooldown de habilidades de árvore
  gameState = 'jogando'; // Volta o estado do jogo para 'jogando'

  // Aumenta a dificuldade com base no nível
  limiteArvoresGanhouAtual = limiteArvoresGanhouBase + (nivel - 1) * 10; // Aumenta 10 árvores por nível
  machadoDoJogo.velocidade = velocidadeMachadoBase + (nivel - 1) * 1.5; // Aumenta a velocidade do machado
  intervaloEntreCortesAtual = max(3000, intervaloEntreCortesBase - (nivel - 1) * 1500); // Diminui o intervalo de corte, mínimo de 3s

  // Lógica para o número de árvores cortadas pelo machado por evento
  // Até o nível 9, aumenta 1 a cada 2 níveis (base + floor((nivel - 1) / 2))
  numArvoresParaCortarAtual = numArvoresParaCortarBase + floor((min(nivel, 9) - 1) / 2);
  // A partir do nível 10, adiciona 2 por nível ao valor que teria no nível 9
  if (nivel >= 10) {
    numArvoresParaCortarAtual += (nivel - 9) * 2;
  }

  // Aumenta a chance de pragas e poluição com o nível
  chanceAparecerPraga = 0.005 + (nivel - 1) * 0.0005;
  chanceAparecerPoluicao = 0.002 + (nivel - 1) * 0.0003;


  console.log("Iniciando Nível " + nivel);
  console.log("Objetivo: " + limiteArvoresGanhouAtual + " árvores. Machado corta: " + numArvoresParaCortarAtual);

  nivel++; // Incrementa o nível para a próxima vez que o jogo for ganho
}
